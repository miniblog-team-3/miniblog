import "./Footer.css";

import React from "react";

export default function Footer() {
  return (
    <>
      <div className="footer-container">
        <h1>footer</h1>
      </div>
    </>
  );
}
